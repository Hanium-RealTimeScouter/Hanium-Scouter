cd ./scouter/agent.host
./host.sh
cd ../..
