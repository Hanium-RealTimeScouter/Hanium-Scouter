cd ./scouter/server
./stop.sh
cd ../..
